<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://fine2find.com/user/vijay.thorat/
 * @since      1.0.0
 *
 * @package    Hippo_Api_Registration_Form
 * @subpackage Hippo_Api_Registration_Form/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Hippo_Api_Registration_Form
 * @subpackage Hippo_Api_Registration_Form/includes
 * @author     Vijay Thorat <thoratvijay30@gmail.com>
 */
class Hippo_Api_Registration_Form_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
