<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://fine2find.com/user/vijay.thorat/
 * @since      1.0.0
 *
 * @package    Hippo_Api_Registration_Form
 * @subpackage Hippo_Api_Registration_Form/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Hippo_Api_Registration_Form
 * @subpackage Hippo_Api_Registration_Form/includes
 * @author     Vijay Thorat <thoratvijay30@gmail.com>
 */
class Hippo_Api_Registration_Form_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'hippo-api-registration-form',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
