<?php
class registration_form {
    public function __construct() {
        add_action('admin_menu',array($this,'hippoAdminMenu'));
    }
         
     
    public function hippoAdminMenu(){
        add_menu_page( 'Hippo Forms', 'Hippo Forms', 'manage_options', 'Hippo Settings', array($this,'pluginAdminMenuPage'), 'dashicons-editor-unlink');
    }
 
    public function pluginAdminMenuPage(){
        echo '<h1>My Plugin Settings</h1>';
    }
}
 
$myPlugin = new registration_form();
